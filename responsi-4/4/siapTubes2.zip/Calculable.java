public interface Calculable {
    public Double value();
}