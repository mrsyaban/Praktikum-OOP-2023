public class PushNotification implements Observer {
    
    @Override
    public void receiveNotif(){
        System.out.println("pesan berhasil disampaikan");
    }

    public void pushNotif(){
        
    }
}