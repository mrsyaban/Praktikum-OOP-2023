public interface Observer {
    public void receiveNotif();
}