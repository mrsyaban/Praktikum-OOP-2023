
public class SMS implements Observer{
    private String notif = "";

    @Override
    public void receiveNotif(){
        
    }
}
